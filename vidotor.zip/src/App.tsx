import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '@/src/hooks/useAuth';
import LandingPage from '@/src/components/LandingPage';
import Dashboard from '@/src/components/Dashboard';
import ProjectDetails from '@/src/components/ProjectDetails';
import VideoReview from '@/src/components/VideoReview';
import { Toaster } from '@/components/ui/sonner';

export default function App() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="h-screen bg-background flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <Router>
      <Routes>
        <Route path="/" element={user ? <Dashboard user={user} /> : <LandingPage />} />
        <Route path="/project/:projectId" element={user ? <ProjectDetails /> : <Navigate to="/" />} />
        <Route path="/video/:videoId" element={<VideoReview />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
      <Toaster position="top-right" theme="dark" />
    </Router>
  );
}

// v2.1 - Improved Error Handling
import { toast } from 'sonner';
import axios from 'axios';

interface UploadProgress {
  loaded: number;
  total: number;
  percentage: number;
}

export async function uploadToYouTube(
  file: File, 
  accessToken: string, 
  onProgress?: (progress: UploadProgress) => void
): Promise<string> {
  console.log('[YouTube Service] Initiating upload for:', file.name);
  const metadata = {
    snippet: {
      title: file.name.replace(/\.[^/.]+$/, ""),
      description: 'Uploaded via Vidotor Video Feedback Platform',
      categoryId: '22', // People & Blogs
    },
    status: {
      privacyStatus: 'unlisted', // Default to unlisted for review
      selfDeclaredMadeForKids: false,
    },
  };

  // Initiate upload via our server-side proxy to avoid CORS issues
  const response = await fetch('/api/yt/init-upload', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      metadata,
      accessToken,
      fileSize: file.size,
      fileType: file.type,
    }),
  });

  const contentType = response.headers.get('content-type');
  if (!contentType || !contentType.includes('application/json')) {
    const text = await response.text();
    console.error('[YouTube Service] Non-JSON response:', text);
    throw new Error(`Server Error: Received HTML instead of JSON. Please refresh.`);
  }

  const data = await response.json();

  if (!data.success) {
    console.error('[YouTube Service] Proxy reported failure:', data.error);
    throw new Error(data.error || 'Failed to initiate upload');
  }

  const { uploadUrl } = data;
  if (!uploadUrl) throw new Error('Critical Error: No upload URL received from proxy');

  console.log('[YouTube Service] Upload URL received, starting binary transfer...');
  return performUpload(uploadUrl, file, onProgress);
}

async function performUpload(
  uploadUrl: string,
  file: File,
  onProgress?: (progress: UploadProgress) => void
): Promise<string> {
  try {
    console.log('[YouTube Service] Proxying binary transfer through server...');
    
    // We now proxy the binary upload through our own server to avoid CORS/Network errors in the browser
    const proxyUrl = `/api/yt/upload-binary?uploadUrl=${encodeURIComponent(uploadUrl)}`;
    
    const response = await axios.put(proxyUrl, file, {
      headers: {
        'Content-Type': file.type,
      },
      onUploadProgress: (progressEvent) => {
        if (onProgress && progressEvent.total) {
          onProgress({
            loaded: progressEvent.loaded,
            total: progressEvent.total,
            percentage: Math.round((progressEvent.loaded / progressEvent.total) * 100),
          });
        }
      },
    });

    console.log('[YouTube Service] Binary transfer via proxy complete');
    return response.data.id;
  } catch (error: any) {
    console.error('[YouTube Service] Binary transfer failed:', error);
    
    if (error.response) {
      throw new Error(`Upload Rejected (${error.response.status}): ${JSON.stringify(error.response.data)}`);
    } else if (error.request) {
      throw new Error('Proxy Connection Error: The browser could not communicate with the upload proxy. The file might be too large or the connection timed out.');
    } else {
      throw new Error(`Upload Error: ${error.message}`);
    }
  }
}

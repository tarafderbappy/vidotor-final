import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { 
  ArrowLeft, 
  Upload, 
  Play, 
  MoreVertical, 
  Share2, 
  Trash2,
  FileVideo,
  Link as LinkIcon,
  MousePointer2,
  Youtube as YoutubeIcon,
  ExternalLink
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { db } from '@/src/lib/firebase';
import { doc, getDoc, collection, onSnapshot, query, addDoc, serverTimestamp, deleteDoc } from 'firebase/firestore';
import { toast } from 'sonner';
import { uploadToYouTube } from '@/src/services/youtubeService';

import ShareModal from '@/src/components/ShareModal';

interface Video {
  id: string;
  youtubeVideoId: string;
  title: string;
  thumbnail: string;
  createdAt: any;
}

export default function ProjectDetails() {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const [project, setProject] = useState<any>(null);
  const [videos, setVideos] = useState<Video[]>([]);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [videoUrl, setVideoUrl] = useState(''); // For MVP, we'll allow pasting YouTube URLs too
  const [videoTitle, setVideoTitle] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);

  useEffect(() => {
    if (!projectId) return;

    const projRef = doc(db, 'projects', projectId);
    getDoc(projRef).then(snap => {
      if (snap.exists()) setProject(snap.data());
    });

    const videosRef = collection(db, 'projects', projectId, 'videos');
    const unsubscribe = onSnapshot(videosRef, (snapshot) => {
      setVideos(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Video)));
    });

    return () => unsubscribe();
  }, [projectId]);

  const handleAddVideo = async () => {
    if (!projectId || !videoUrl || !videoTitle) return;

    // Extract YouTube ID
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = videoUrl.match(regExp);
    const youtubeId = (match && match[2].length === 11) ? match[2] : null;

    if (!youtubeId) {
      toast.error("Invalid YouTube URL");
      return;
    }

    await addDoc(collection(db, 'projects', projectId, 'videos'), {
      youtubeVideoId: youtubeId,
      title: videoTitle,
      thumbnail: `https://img.youtube.com/vi/${youtubeId}/mqdefault.jpg`,
      createdAt: serverTimestamp()
    });

    setVideoUrl('');
    setVideoTitle('');
    setIsUploadOpen(false);
    toast.success("Video added to session");
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      const file = files[0];
      if (file.type.startsWith('video/')) {
        handleVideoFileUpload(file);
        return;
      } else {
        toast.error("Please drop a valid video file");
        return;
      }
    }

    const url = e.dataTransfer.getData('text/plain');
    if (!url) return;

    // Extract YouTube ID
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    const youtubeId = (match && match[2].length === 11) ? match[2] : null;

    if (!youtubeId) {
      toast.error("Invalid YouTube URL dropped");
      return;
    }

    try {
      // For dropped URLs, we'll use a generic title or try to fetch it if we had an API
      // For now, let's use "Dropped Video" as placeholder
      await addDoc(collection(db, 'projects', projectId!, 'videos'), {
        youtubeVideoId: youtubeId,
        title: "New Video",
        thumbnail: `https://img.youtube.com/vi/${youtubeId}/mqdefault.jpg`,
        createdAt: serverTimestamp()
      });
      toast.success("Video added via drop!");
    } catch (error) {
      console.error("Error adding dropped video", error);
      toast.error("Failed to add dropped video");
    }
  };

  const handleVideoFileUpload = async (file: File) => {
    const accessToken = localStorage.getItem('yt_access_token');
    
    if (!accessToken) {
      toast.error("YouTube not connected. Please sign in again to enable uploads.");
      return;
    }

    setUploadProgress(0);
    const toastId = toast.loading(`Uploading "${file.name}" to YouTube...`);

    try {
      const youtubeId = await uploadToYouTube(file, accessToken, (progress) => {
        setUploadProgress(progress.percentage);
      });

      await addDoc(collection(db, 'projects', projectId!, 'videos'), {
        youtubeVideoId: youtubeId,
        title: file.name.replace(/\.[^/.]+$/, ""),
        thumbnail: `https://img.youtube.com/vi/${youtubeId}/mqdefault.jpg`,
        createdAt: serverTimestamp()
      });

      toast.success("Video uploaded and added to session!", { id: toastId });
    } catch (error: any) {
      console.error("Upload error", error);
      const errorMessage = error.message || "";
      
      if (errorMessage.includes("YouTube Data API v3 has not been used")) {
        const projectIdFromError = errorMessage.match(/project (\d+)/)?.[1] || "758217010918";
        toast.error(
          <div className="flex flex-col gap-3 p-1">
            <div className="flex items-center gap-2 text-status-rejected">
              <YoutubeIcon className="w-5 h-5" />
              <p className="font-bold">YouTube API Not Enabled</p>
            </div>
            <p className="text-xs text-text-secondary leading-relaxed">
              It looks like the API is disabled for project <span className="font-mono font-bold text-foreground bg-section px-1 rounded">{projectIdFromError}</span>. 
              You might have enabled it for a different project by mistake.
            </p>
            <div className="flex flex-col gap-2">
              <a 
                href={`https://console.developers.google.com/apis/api/youtube.googleapis.com/overview?project=${projectIdFromError}`}
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 bg-primary text-white py-2 rounded-xl text-xs font-bold hover:bg-primary-hover transition-colors"
              >
                Open Correct Project Console
                <ExternalLink className="w-3 h-3" />
              </a>
              <button
                onClick={() => {
                  localStorage.removeItem('yt_access_token');
                  window.location.reload();
                }}
                className="text-[10px] font-extrabold uppercase tracking-widest text-text-muted hover:text-foreground transition-colors"
              >
                Then Refresh Session
              </button>
            </div>
          </div>,
          { id: toastId, duration: 15000 }
        );
      } else {
        toast.error(errorMessage || "Failed to upload video", { id: toastId });
      }
    } finally {
      setUploadProgress(null);
    }
  };

  if (!project) return null;

  return (
    <div 
      className={`min-h-screen bg-background text-foreground p-16 font-sans bg-grid-subtle transition-colors duration-300 ${isDragging ? 'bg-primary/5' : ''}`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      {/* Drop Overlay */}
      {(isDragging || uploadProgress !== null) && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center pointer-events-none bg-background/40 backdrop-blur-sm">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white border-4 border-dashed border-primary rounded-[60px] p-20 shadow-2xl flex flex-col items-center gap-8 min-w-[500px]"
          >
            <div className="w-32 h-32 bg-primary rounded-[40px] flex items-center justify-center animate-bounce">
              {uploadProgress !== null ? (
                <Upload className="w-16 h-16 text-white" />
              ) : (
                <FileVideo className="w-16 h-16 text-white" />
              )}
            </div>
            <div className="text-center w-full">
              <h2 className="text-5xl font-extrabold tracking-tighter mb-4">
                {uploadProgress !== null ? 'Uploading Video...' : 'Drop Video File'}
              </h2>
              <p className="text-xl text-text-secondary font-medium mb-8">
                {uploadProgress !== null 
                  ? `Processing your file: ${uploadProgress}%` 
                  : 'Release to upload directly to YouTube'}
              </p>
              
              {uploadProgress !== null && (
                <div className="w-full h-4 bg-section rounded-full overflow-hidden border border-border">
                  <motion.div 
                    className="h-full bg-primary"
                    initial={{ width: 0 }}
                    animate={{ width: `${uploadProgress}%` }}
                    transition={{ duration: 0.3 }}
                  />
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}

      <div className="max-w-6xl mx-auto">
        <div className="flex items-end gap-8 mb-16">
          <Button variant="ghost" size="icon" onClick={() => navigate('/')} className="text-text-muted hover:text-primary hover:bg-accent-peach rounded-full w-14 h-14 shrink-0">
            <ArrowLeft className="w-8 h-8" />
          </Button>
          <div className="flex-1">
            <h1 className="text-5xl md:text-6xl font-extrabold tracking-tighter mb-4 leading-none">{project.title}</h1>
            <p className="text-lg text-text-secondary font-medium">Manage videos and feedback for this session.</p>
          </div>
          
          <div className="flex gap-4">
            {projectId && <ShareModal targetId={projectId} targetType="project" />}
            
            <Dialog open={isUploadOpen} onOpenChange={setIsUploadOpen}>
              <DialogTrigger
                render={
                  <Button className="bg-primary hover:bg-primary-hover text-white rounded-full px-10 h-14 font-bold shadow-xl shadow-primary/20 transition-all hover:scale-105">
                    <Upload className="w-5 h-5 mr-2" />
                    Add Video
                  </Button>
                }
              />
              <DialogContent className="bg-white border-border text-foreground rounded-[32px] p-10 shadow-2xl">
                <DialogHeader>
                  <DialogTitle className="text-3xl font-extrabold tracking-tight">Add Video to Session</DialogTitle>
                </DialogHeader>
                <div className="space-y-8 pt-8">
                  <div className="space-y-3">
                    <label className="text-[10px] font-extrabold text-text-muted uppercase tracking-[0.2em]">Video Title</label>
                    <Input 
                      placeholder="e.g. Final Cut v1" 
                      value={videoTitle}
                      onChange={(e) => setVideoTitle(e.target.value)}
                      className="bg-section border-border h-14 rounded-2xl focus:ring-2 focus:ring-primary/20 transition-all text-lg font-medium"
                    />
                  </div>
                  <div className="space-y-3">
                    <label className="text-[10px] font-extrabold text-text-muted uppercase tracking-[0.2em]">YouTube URL</label>
                    <Input 
                      placeholder="https://www.youtube.com/watch?v=..." 
                      value={videoUrl}
                      onChange={(e) => setVideoUrl(e.target.value)}
                      className="bg-section border-border h-14 rounded-2xl focus:ring-2 focus:ring-primary/20 transition-all text-lg font-medium"
                    />
                    <p className="text-[11px] text-text-muted font-medium italic">For the MVP, you can paste existing YouTube links. Direct upload coming soon.</p>
                  </div>
                  <Button onClick={handleAddVideo} className="w-full bg-primary hover:bg-primary-hover text-white h-14 rounded-full font-bold shadow-xl shadow-primary/20 text-lg">
                    Add Video
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
          {videos.map((video) => (
            <Card 
              key={video.id} 
              className="bg-white border border-border overflow-hidden hover:border-primary/20 hover:shadow-2xl transition-all group cursor-pointer rounded-[32px]"
              onClick={() => navigate(`/video/${video.id}?projectId=${projectId}`)}
            >
              <div className="aspect-video relative overflow-hidden">
                <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[1.5s] opacity-90 group-hover:opacity-100" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 bg-primary/10 group-hover:bg-transparent transition-colors duration-700" />
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-500 scale-90 group-hover:scale-100">
                  <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-2xl">
                    <Play className="w-7 h-7 fill-primary text-primary" />
                  </div>
                </div>
              </div>
              <div className="p-8 flex items-center justify-between">
                <div>
                  <h3 className="font-extrabold truncate tracking-tight text-xl mb-1 group-hover:text-primary transition-colors">{video.title}</h3>
                  <p className="text-[11px] text-text-muted font-extrabold uppercase tracking-[0.2em]">{video.createdAt?.toDate().toLocaleDateString() || 'Just now'}</p>
                </div>
                <Button variant="ghost" size="icon" className="text-text-muted hover:text-status-error hover:bg-status-error/10 rounded-full" onClick={(e) => e.stopPropagation()}>
                  <Trash2 className="w-5 h-5" />
                </Button>
              </div>
            </Card>
          ))}

          {videos.length === 0 && (
            <div className="col-span-full py-32 text-center border-2 border-dashed border-border rounded-[40px] bg-white/50">
              <div className="w-20 h-20 bg-accent-peach rounded-[24px] flex items-center justify-center mx-auto mb-8">
                <FileVideo className="w-10 h-10 text-primary" />
              </div>
              <h3 className="text-3xl font-extrabold mb-4 tracking-tight">No videos yet</h3>
              <p className="text-text-secondary mb-10 max-w-sm mx-auto font-medium text-lg leading-relaxed">Add your first video to start the review process with your clients in style.</p>
              <Button variant="outline" onClick={() => setIsUploadOpen(true)} className="border-border-strong hover:bg-accent-peach hover:text-primary text-foreground font-bold px-10 h-14 rounded-full transition-all">
                Add Your First Video
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

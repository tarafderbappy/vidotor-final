import React, { useState } from 'react';
import { Share2, Copy, Check, Globe, Lock, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { db } from '@/src/lib/firebase';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { toast } from 'sonner';

export default function ShareModal({ targetId, targetType }: { targetId: string, targetType: 'project' | 'video' }) {
  const [isOpen, setIsOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [shareUrl, setShareUrl] = useState('');

  const generateLink = async () => {
    const token = Math.random().toString(36).substring(2, 15);
    const linkId = targetId; // For MVP, use targetId as linkId for simplicity
    
    await setDoc(doc(db, 'shareLinks', linkId), {
      targetId,
      targetType,
      token,
      permissionType: 'comment',
      createdAt: serverTimestamp()
    });

    const url = `${window.location.origin}/${targetType}/${targetId}?token=${token}`;
    setShareUrl(url);
    toast.success("Review link generated!");
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success("Link copied");
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger
        render={
          <Button variant="outline" size="sm" className="border-border-strong hover:bg-accent-peach hover:text-primary text-[11px] font-extrabold uppercase tracking-[0.2em] rounded-full px-6 h-10 transition-all">
            <Share2 className="w-4 h-4 mr-2" />
            Share
          </Button>
        }
      />
      <DialogContent className="bg-white border-border text-foreground sm:max-w-md rounded-[32px] p-10 shadow-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3 text-2xl font-extrabold tracking-tight">
            <Globe className="w-6 h-6 text-primary" />
            Share {targetType === 'project' ? 'Session' : 'Video'}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-8 py-6">
          {!shareUrl ? (
            <div className="text-center space-y-8">
              <div className="p-8 bg-section rounded-[24px] border border-border">
                <Lock className="w-10 h-10 text-text-muted mx-auto mb-4" />
                <p className="text-sm text-text-secondary font-medium leading-relaxed">Generate a secure review link to share with clients. They can watch and mark without an account.</p>
              </div>
              <Button onClick={generateLink} className="w-full bg-primary hover:bg-primary-hover text-white h-14 rounded-full font-bold shadow-xl shadow-primary/20 text-lg transition-all hover:scale-105">
                Generate Review Link
              </Button>
            </div>
          ) : (
            <div className="space-y-8">
              <div className="flex gap-3">
                <Input 
                  value={shareUrl} 
                  readOnly 
                  className="bg-section border-border text-[11px] font-mono h-14 rounded-2xl focus:ring-0"
                />
                <Button onClick={copyToClipboard} size="icon" className="bg-primary hover:bg-primary-hover shrink-0 h-14 w-14 rounded-2xl shadow-lg shadow-primary/20 transition-all hover:scale-105">
                  {copied ? <Check className="w-5 h-5 text-white" /> : <Copy className="w-5 h-5 text-white" />}
                </Button>
              </div>
              
              <div className="flex items-center justify-between p-6 bg-section rounded-[24px] border border-border">
                <div className="flex items-center gap-3 text-[10px] font-extrabold text-text-muted uppercase tracking-[0.2em]">
                  <Clock className="w-4 h-4" />
                  <span>Link never expires</span>
                </div>
                <Button variant="link" className="text-status-error h-auto p-0 text-[10px] font-extrabold uppercase tracking-[0.2em] hover:text-status-error/80">Revoke Access</Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

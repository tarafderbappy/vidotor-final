import React, { useState, useEffect, useRef } from 'react';
import { useParams, useSearchParams, useNavigate } from 'react-router-dom';
import YouTube from 'react-youtube';
import { 
  ArrowLeft, 
  MessageSquare, 
  Send, 
  Clock, 
  Trash2,
  ChevronRight,
  Share2,
  Play
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { db, auth } from '@/src/lib/firebase';
import { 
  doc, 
  getDoc, 
  collection, 
  onSnapshot, 
  query, 
  addDoc, 
  serverTimestamp, 
  orderBy,
  deleteDoc
} from 'firebase/firestore';
import { formatTimestamp } from '@/src/lib/utils';
import { toast } from 'sonner';
import ShareModal from '@/src/components/ShareModal';

interface Comment {
  id: string;
  userId: string;
  userName: string;
  userPhoto: string;
  content: string;
  timestamp: number;
  createdAt: any;
}

export default function VideoReview() {
  const { videoId } = useParams();
  const [searchParams] = useSearchParams();
  const projectId = searchParams.get('projectId');
  const navigate = useNavigate();
  
  const [video, setVideo] = useState<any>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [player, setPlayer] = useState<any>(null);

  useEffect(() => {
    if (!videoId || !projectId) return;

    const videoRef = doc(db, 'projects', projectId, 'videos', videoId);
    getDoc(videoRef).then(snap => {
      if (snap.exists()) setVideo(snap.data());
    });

    const commentsRef = collection(db, 'videos', videoId, 'comments');
    const q = query(commentsRef, orderBy('timestamp', 'asc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setComments(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Comment)));
    });

    return () => unsubscribe();
  }, [videoId, projectId]);

  const handleAddComment = async () => {
    if (!newComment.trim() || !videoId || !auth.currentUser) return;

    const timestamp = player ? player.getCurrentTime() : 0;

    await addDoc(collection(db, 'videos', videoId, 'comments'), {
      videoId,
      userId: auth.currentUser.uid,
      userName: auth.currentUser.displayName,
      userPhoto: auth.currentUser.photoURL,
      content: newComment,
      timestamp,
      createdAt: serverTimestamp()
    });

    setNewComment('');
    toast.success("Note added at " + formatTimestamp(timestamp));
  };

  const jumpToTime = (time: number) => {
    if (player) {
      player.seekTo(time);
      player.playVideo();
    }
  };

  const onReady = (event: any) => {
    setPlayer(event.target);
  };

  if (!video) return null;

  return (
    <div className="h-screen bg-background text-foreground flex flex-col font-sans overflow-hidden bg-grid-subtle">
      {/* Header */}
      <header className="h-20 border-b border-border flex items-center justify-between px-10 bg-white/80 backdrop-blur-xl z-10">
        <div className="flex items-center gap-6">
          <Button variant="ghost" size="icon" onClick={() => navigate(`/project/${projectId}`)} className="text-text-muted hover:text-primary hover:bg-accent-peach rounded-full w-12 h-12">
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <div className="flex items-center gap-3 text-[11px] font-extrabold uppercase tracking-[0.2em]">
            <span className="text-text-muted">Sessions / {video.projectTitle || 'Session'}</span>
            <span className="text-text-muted">/</span>
            <h1 className="text-foreground">{video.title}</h1>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <div className="hidden md:flex items-center gap-2 px-4 py-2 bg-accent-peach text-primary rounded-full text-[10px] font-extrabold tracking-[0.2em] border border-primary/10">
            <div className="w-1.5 h-1.5 bg-primary rounded-full shadow-[0_0_8px_rgba(176,75,50,0.4)]" />
            LIVE REVIEW
          </div>
          {videoId && <ShareModal targetId={videoId} targetType="video" />}
          <div className="w-10 h-10 rounded-full bg-section border-2 border-white shadow-sm flex items-center justify-center text-[11px] font-extrabold text-primary">
            {auth.currentUser?.displayName?.split(' ').map(n => n[0]).join('') || 'U'}
          </div>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* Main Player Area */}
        <main className="flex-1 bg-background flex flex-col p-10 overflow-hidden">
          <div className="flex-1 bg-black rounded-[40px] overflow-hidden shadow-2xl border-8 border-white relative group">
            <YouTube 
              videoId={video.youtubeVideoId} 
              onReady={onReady}
              opts={{
                width: '100%',
                height: '100%',
                playerVars: {
                  autoplay: 0,
                  modestbranding: 1,
                  rel: 0,
                  controls: 1
                }
              }}
              className="w-full h-full"
            />
            <div className="absolute bottom-6 right-6 opacity-40 text-[10px] text-white font-extrabold tracking-[0.3em] pointer-events-none uppercase">
              YouTube Backend
            </div>
          </div>
          
          {/* Custom Controls Mockup */}
          <div className="h-24 bg-white mt-10 rounded-[32px] border border-border flex items-center px-10 gap-10 shadow-xl">
            <Button variant="ghost" size="icon" className="text-text-muted hover:text-primary hover:bg-accent-peach rounded-full w-12 h-12">
              <Play className="w-6 h-6 fill-current" />
            </Button>
            <span className="text-xs font-mono font-bold text-text-muted w-24 tracking-tighter">
              {player ? formatTimestamp(player.getCurrentTime()) : '0:00'} / {video.duration ? formatTimestamp(video.duration) : '--:--'}
            </span>
            <div className="flex-1 h-2 bg-section rounded-full relative">
              <div className="absolute inset-y-0 left-0 bg-primary rounded-full shadow-lg shadow-primary/20" style={{ width: '45%' }} />
              {comments.map(c => (
                <div 
                  key={c.id}
                  className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-primary border-4 border-white rounded-full shadow-xl cursor-pointer hover:scale-150 transition-transform z-10"
                  style={{ left: `${(c.timestamp / (video.duration || 100)) * 100}%` }}
                  onClick={() => jumpToTime(c.timestamp)}
                />
              ))}
            </div>
          </div>
        </main>

        {/* Sidebar Notes */}
        <aside className="w-[380px] border-l border-border flex flex-col bg-white">
          <div className="p-8 border-b border-border flex items-center justify-between">
            <h2 className="font-extrabold text-lg tracking-tight">Notes ({comments.length})</h2>
            <select className="text-[10px] font-extrabold bg-transparent border-none text-text-muted focus:ring-0 cursor-pointer uppercase tracking-[0.2em]">
              <option>Newest first</option>
            </select>
          </div>

          <ScrollArea className="flex-1">
            <div className="p-6 space-y-4">
              {comments.map((comment) => (
                <div key={comment.id} className="group relative p-6 bg-section rounded-[24px] border border-transparent hover:border-primary/20 hover:bg-white hover:shadow-xl transition-all">
                  <div className="flex items-center gap-3 mb-4">
                    <img src={comment.userPhoto} alt="" className="w-8 h-8 rounded-full border-2 border-white shadow-sm" referrerPolicy="no-referrer" />
                    <span className="text-sm font-extrabold text-foreground tracking-tight">{comment.userName}</span>
                    <button 
                      onClick={() => jumpToTime(comment.timestamp)}
                      className="ml-auto px-3 py-1 bg-accent-peach text-primary text-[10px] font-mono font-extrabold rounded-lg border border-primary/10"
                    >
                      {formatTimestamp(comment.timestamp)}
                    </button>
                  </div>
                  <p className="text-sm text-text-secondary leading-relaxed font-medium">{comment.content}</p>
                  <div className="flex items-center gap-6 mt-4 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button className="text-[10px] font-extrabold text-text-muted hover:text-primary uppercase tracking-widest">Reply</button>
                    <button className="text-[10px] font-extrabold text-text-muted hover:text-status-error uppercase tracking-widest">Delete</button>
                  </div>
                </div>
              ))}

              {comments.length === 0 && (
                <div className="text-center py-32">
                  <div className="w-16 h-16 bg-section rounded-[24px] flex items-center justify-center mx-auto mb-6">
                    <MessageSquare className="w-8 h-8 text-text-muted" />
                  </div>
                  <p className="text-[11px] font-extrabold text-text-muted uppercase tracking-[0.3em]">No notes yet.</p>
                </div>
              )}
            </div>
          </ScrollArea>

          <div className="p-8 border-t border-border bg-section/50">
            <textarea 
              placeholder={`Add a note at ${player ? formatTimestamp(player.getCurrentTime()) : '0:00'}...`}
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              className="w-full bg-white border border-border rounded-2xl p-5 text-sm h-32 resize-none mb-6 focus:ring-2 focus:ring-primary/20 focus:border-primary/50 outline-none transition-all placeholder:text-text-muted font-medium shadow-sm"
            />
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-extrabold text-text-muted uppercase tracking-[0.2em]">Mark at {player ? formatTimestamp(player.getCurrentTime()) : '0:00'}</span>
              <Button 
                onClick={handleAddComment}
                className="bg-primary hover:bg-primary-hover text-white rounded-full px-8 h-12 text-sm font-bold shadow-lg shadow-primary/20"
              >
                Send Note
              </Button>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

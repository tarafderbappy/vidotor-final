import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  LayoutDashboard, 
  FolderPlus, 
  Settings, 
  LogOut, 
  Plus, 
  MoreVertical, 
  Clock,
  Youtube as YoutubeIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { auth, db, googleProvider } from '@/src/lib/firebase';
import { collection, query, where, onSnapshot, addDoc, serverTimestamp, doc, getDoc, updateDoc } from 'firebase/firestore';
import { User, signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

import { useNavigate } from 'react-router-dom';

interface Project {
  id: string;
  title: string;
  description: string;
  createdAt: any;
}

export default function Dashboard({ user }: { user: User }) {
  const [projects, setProjects] = useState<Project[]>([]);
  const [newProjectTitle, setNewProjectTitle] = useState('');
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [youtubeConnected, setYoutubeConnected] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const userRef = doc(db, 'users', user.uid);
    getDoc(userRef).then(snap => {
      if (snap.exists()) {
        setYoutubeConnected(snap.data().youtubeConnected || false);
      }
    });
    
    const q = query(collection(db, 'projects'), where('userId', '==', user.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const projs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Project));
      setProjects(projs);
    });
    return () => unsubscribe();
  }, [user.uid]);

  const handleCreateProject = async () => {
    if (!newProjectTitle.trim()) return;
    await addDoc(collection(db, 'projects'), {
      title: newProjectTitle,
      userId: user.uid,
      createdAt: serverTimestamp(),
      description: ''
    });
    setNewProjectTitle('');
    setIsCreateOpen(false);
  };

  const handleConnectYoutube = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const credential = GoogleAuthProvider.credentialFromResult(result);
      if (credential?.accessToken) {
        localStorage.setItem('yt_access_token', credential.accessToken);
        const userRef = doc(db, 'users', user.uid);
        await updateDoc(userRef, {
          youtubeConnected: true
        });
        setYoutubeConnected(true);
        toast.success("YouTube connected successfully!");
      }
    } catch (error: any) {
      console.error("Error connecting YouTube", error);
      toast.error("Failed to connect YouTube");
    }
  };

  return (
    <div className="flex h-screen bg-background text-foreground font-sans overflow-hidden bg-grid-subtle">
      {/* Sidebar */}
      <aside className="w-[280px] border-r border-border flex flex-col bg-white">
        <div className="p-10 flex items-center gap-3">
          <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center shadow-lg shadow-primary/20">
            <LayoutDashboard className="w-6 h-6 text-white" />
          </div>
          <span className="font-extrabold text-2xl tracking-tighter">Vidotor</span>
        </div>

        <nav className="flex-1 px-4 space-y-2">
          <NavItem icon={<LayoutDashboard className="w-5 h-5" />} label="Sessions" active />
          <div className="pt-10 pb-4 px-6">
            <p className="text-[10px] font-extrabold text-text-muted uppercase tracking-[0.3em]">Integrations</p>
          </div>
          <div className="space-y-2 px-2">
            <div className={`flex items-center justify-between px-6 py-4 rounded-2xl transition-all border ${youtubeConnected ? 'bg-status-approved/5 text-status-approved border-status-approved/20' : 'text-text-muted border-transparent hover:bg-section'}`}>
              <div className="flex items-center gap-3">
                <YoutubeIcon className="w-5 h-5" />
                <span className="font-bold text-sm">YouTube</span>
              </div>
              {youtubeConnected ? (
                <div className="w-2 h-2 bg-status-approved rounded-full shadow-[0_0_8px_#2D6A4F]" />
              ) : (
                <Button 
                  variant="link" 
                  onClick={handleConnectYoutube}
                  className="text-text-muted h-auto p-0 text-[11px] font-extrabold hover:text-primary uppercase tracking-widest"
                >
                  Connect
                </Button>
              )}
            </div>
            
            {youtubeConnected && (
              <div className="px-6 py-3 bg-accent-peach/30 rounded-xl border border-primary/10">
                <p className="text-[9px] font-extrabold text-primary uppercase tracking-wider mb-1">Action Required</p>
                <p className="text-[10px] text-text-secondary leading-tight">
                  Ensure <a href="https://console.developers.google.com/apis/api/youtube.googleapis.com/overview" target="_blank" rel="noopener noreferrer" className="underline font-bold">YouTube API</a> is enabled in your console for uploads.
                </p>
              </div>
            )}
          </div>
          <NavItem icon={<Settings className="w-5 h-5" />} label="Settings" />
        </nav>

        <div className="p-8 border-t border-border">
          <div className="flex items-center gap-4 p-4 rounded-2xl bg-section border border-border">
            <img src={user.photoURL || ''} alt="" className="w-10 h-10 rounded-full border-2 border-white shadow-sm" referrerPolicy="no-referrer" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold truncate tracking-tight">{user.displayName}</p>
              <p className="text-[10px] text-primary font-extrabold uppercase tracking-widest">Pro Creator</p>
            </div>
            <Button variant="ghost" size="icon" onClick={() => auth.signOut()} className="text-text-muted hover:text-status-error hover:bg-status-error/10">
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-16">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-end justify-between mb-16">
            <div>
              <h1 className="text-5xl font-extrabold mb-4 tracking-tighter leading-none">My Sessions</h1>
              <p className="text-lg text-text-secondary font-medium">Manage your video reviews and collaborations.</p>
            </div>
            
            <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
              <DialogTrigger
                render={
                  <Button className="bg-primary hover:bg-primary-hover text-white rounded-full px-10 h-14 font-bold shadow-xl shadow-primary/20 transition-all hover:scale-105">
                    <Plus className="w-6 h-6 mr-2" />
                    New Session
                  </Button>
                }
              />
              <DialogContent className="bg-white border-border text-foreground rounded-[32px] p-10 shadow-2xl">
                <DialogHeader>
                  <DialogTitle className="text-3xl font-extrabold tracking-tight">Create New Session</DialogTitle>
                </DialogHeader>
                <div className="space-y-8 pt-8">
                  <div className="space-y-3">
                    <label className="text-[10px] font-extrabold text-text-muted uppercase tracking-[0.2em]">Session Title</label>
                    <Input 
                      placeholder="e.g. Summer Campaign v1" 
                      value={newProjectTitle}
                      onChange={(e) => setNewProjectTitle(e.target.value)}
                      className="bg-section border-border h-14 rounded-2xl focus:ring-2 focus:ring-primary/20 transition-all text-lg font-medium"
                    />
                  </div>
                  <Button onClick={handleCreateProject} className="w-full bg-primary hover:bg-primary-hover text-white h-14 rounded-full font-bold shadow-xl shadow-primary/20 text-lg">
                    Create Session
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
            {projects.map((project: Project) => (
              // @ts-ignore
              <ProjectCard key={project.id} project={project} onClick={() => navigate(`/project/${project.id}`)} />
            ))}
            
            {projects.length === 0 && (
              <div className="col-span-full py-32 text-center border-2 border-dashed border-border rounded-[40px] bg-white/50">
                <div className="w-20 h-20 bg-accent-peach rounded-[24px] flex items-center justify-center mx-auto mb-8">
                  <FolderPlus className="w-10 h-10 text-primary" />
                </div>
                <h3 className="text-3xl font-extrabold mb-4 tracking-tight">No sessions yet</h3>
                <p className="text-text-secondary mb-10 max-w-sm mx-auto font-medium text-lg leading-relaxed">Create your first session to start reviewing videos with your team in style.</p>
                <Button variant="outline" onClick={() => setIsCreateOpen(true)} className="border-border-strong hover:bg-accent-peach hover:text-primary text-foreground font-bold px-10 h-14 rounded-full transition-all">
                  Create Your First Session
                </Button>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

function NavItem({ icon, label, active = false }: { icon: React.ReactNode, label: string, active?: boolean }) {
  return (
    <div className={`flex items-center gap-4 px-6 py-4 cursor-pointer transition-all relative group rounded-2xl ${active ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'text-text-secondary hover:bg-section'}`}>
      <div className={`${active ? 'text-white' : 'text-text-muted group-hover:text-primary'} transition-colors`}>
        {icon}
      </div>
      <span className="font-bold text-sm tracking-tight">{label}</span>
      {active && (
        <motion.div layoutId="activeNav" className="absolute inset-0 bg-primary rounded-2xl -z-10" />
      )}
    </div>
  );
}

function ProjectCard({ project, onClick }: { project: any, onClick: any }) {
  return (
    <Card 
      className="bg-white border border-border p-10 hover:border-primary/20 hover:shadow-2xl transition-all group cursor-pointer rounded-[32px] relative overflow-hidden"
      onClick={onClick}
    >
      <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 blur-3xl -z-10 group-hover:bg-primary/10 transition-colors" />
      <div className="flex items-start justify-between mb-10">
        <div className="w-14 h-14 bg-section rounded-2xl flex items-center justify-center group-hover:bg-primary transition-all duration-500">
          <FolderPlus className="w-7 h-7 text-primary group-hover:text-white transition-colors" />
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger
            render={
              <Button variant="ghost" size="icon" className="text-text-muted hover:text-foreground hover:bg-section rounded-full" onClick={(e) => e.stopPropagation()}>
                <MoreVertical className="w-5 h-5" />
              </Button>
            }
          />
          <DropdownMenuContent align="end" className="bg-white border border-border text-foreground rounded-2xl p-2 shadow-xl">
            <DropdownMenuItem className="hover:bg-section cursor-pointer font-bold rounded-xl px-4 py-2 text-sm">Rename</DropdownMenuItem>
            <DropdownMenuItem className="text-status-error hover:bg-status-error/10 cursor-pointer font-bold rounded-xl px-4 py-2 text-sm">Delete</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      <h3 className="text-2xl font-extrabold mb-3 truncate tracking-tight group-hover:text-primary transition-colors">{project.title}</h3>
      <div className="flex items-center gap-2 text-[11px] text-text-muted font-extrabold uppercase tracking-[0.2em]">
        <Clock className="w-4 h-4" />
        <span>{project.createdAt?.toDate().toLocaleDateString() || 'Just now'}</span>
      </div>
    </Card>
  );
}

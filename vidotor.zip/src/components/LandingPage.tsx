import React from 'react';
import { motion } from 'motion/react';
import { 
  LayoutDashboard, 
  Play, 
  Youtube, 
  MessageSquare, 
  Share2, 
  ArrowRight,
  CheckCircle2,
  Star
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { auth, db, googleProvider } from '@/src/lib/firebase';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { doc, updateDoc } from 'firebase/firestore';

const FeatureCard = ({ icon, title, description, delay = 0 }: { icon: React.ReactNode, title: string, description: string, delay?: number }) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.5, delay }}
    className="p-10 rounded-[32px] bg-white border border-border hover:border-primary/20 transition-all group"
  >
    <div className="w-14 h-14 bg-accent-peach rounded-2xl flex items-center justify-center mb-8 group-hover:scale-110 transition-transform">
      <div className="text-primary">{icon}</div>
    </div>
    <h3 className="text-2xl font-bold mb-4 tracking-tight">{title}</h3>
    <p className="text-text-secondary leading-relaxed font-medium">{description}</p>
  </motion.div>
);

export default function LandingPage() {
  const [isLoading, setIsLoading] = React.useState(false);

  const handleLogin = async () => {
    if (isLoading) return;
    setIsLoading(true);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const credential = GoogleAuthProvider.credentialFromResult(result);
      if (credential?.accessToken) {
        localStorage.setItem('yt_access_token', credential.accessToken);
        // Update user record in Firestore
        const userRef = doc(db, 'users', result.user.uid);
        await updateDoc(userRef, {
          youtubeConnected: true
        });
      }
    } catch (error: any) {
      if (error.code === 'auth/cancelled-popup-request') {
        // Ignore this error as it's just a duplicate request
        return;
      }
      if (error.code === 'auth/popup-closed-by-user') {
        // User closed the popup, no need to show a scary error
        return;
      }
      console.error("Error signing in", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground font-sans selection:bg-primary/10 bg-grid-subtle">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-xl h-20 flex items-center border-b border-border/40">
        <div className="max-w-[1400px] mx-auto w-full px-8 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center shadow-lg shadow-primary/20">
              <LayoutDashboard className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-extrabold tracking-tighter">Vidotor</span>
          </div>
          <div className="hidden lg:flex items-center gap-12 text-[13px] font-bold uppercase tracking-widest text-text-secondary">
            <a href="#features" className="hover:text-primary transition-colors">Features</a>
            <a href="#how-it-works" className="hover:text-primary transition-colors">How it works</a>
            <a href="#pricing" className="hover:text-primary transition-colors">Pricing</a>
          </div>
          <div className="flex items-center gap-6">
            <button 
              onClick={handleLogin} 
              disabled={isLoading}
              className="text-[13px] font-bold uppercase tracking-widest hover:text-primary transition-colors disabled:opacity-50"
            >
              {isLoading ? 'Signing In...' : 'Sign In'}
            </button>
            <Button 
              onClick={handleLogin} 
              disabled={isLoading}
              className="bg-primary hover:bg-primary-hover text-white rounded-full px-8 h-12 text-sm font-bold shadow-xl shadow-primary/20 transition-all hover:scale-105 disabled:opacity-50"
            >
              {isLoading ? 'Starting...' : 'Start Creating'}
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-48 pb-32 px-8 relative overflow-hidden">
        <div className="max-w-[1400px] mx-auto">
          <div className="grid lg:grid-cols-2 gap-20 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent-peach text-primary text-[12px] font-extrabold mb-12 tracking-[0.2em] border border-primary/10">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                </span>
                THE CREATOR'S CHOICE
              </div>
              <h1 className="text-7xl md:text-9xl font-extrabold tracking-tighter mb-10 leading-[0.9] text-foreground">
                Where video <br />
                <span className="text-primary italic">feedback</span> <br />
                happens.
              </h1>
              <p className="text-xl md:text-2xl text-text-secondary max-w-xl mb-14 leading-relaxed font-medium">
                The most stylish way to review videos. Connect YouTube, share links, and get marks directly on the timeline.
              </p>
              <div className="flex flex-col sm:flex-row items-center gap-6">
                <Button 
                  onClick={handleLogin} 
                  disabled={isLoading}
                  size="lg" 
                  className="bg-primary hover:bg-primary-hover text-white px-10 h-16 text-lg font-bold rounded-full shadow-2xl shadow-primary/30 transition-all hover:scale-105 group w-full sm:w-auto disabled:opacity-50"
                >
                  {isLoading ? 'Signing In...' : 'Get Started Free'}
                  {!isLoading && <ArrowRight className="ml-2 w-6 h-6 group-hover:translate-x-1 transition-transform" />}
                </Button>
                <div className="flex items-center gap-4">
                  <div className="flex -space-x-3">
                    {[1,2,3,4].map(i => (
                      <img key={i} src={`https://picsum.photos/seed/user${i}/100/100`} className="w-10 h-10 rounded-full border-2 border-background" alt="" referrerPolicy="no-referrer" />
                    ))}
                  </div>
                  <div className="text-sm font-bold">
                    <div className="flex text-primary mb-0.5">
                      {[1,2,3,4,5].map(i => <Star key={i} className="w-3 h-3 fill-current" />)}
                    </div>
                    <span className="text-text-muted uppercase tracking-widest text-[10px]">Trusted by 2k+ creators</span>
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="relative"
            >
              <div className="absolute -inset-10 bg-primary/5 rounded-full blur-[120px] -z-10" />
              <div className="relative border-[12px] border-white rounded-[40px] overflow-hidden shadow-[0_60px_120px_rgba(0,0,0,0.1)] bg-white">
                <div className="aspect-[4/3] bg-section flex items-center justify-center relative group overflow-hidden">
                  <img 
                    src="https://picsum.photos/seed/vidotor-hero/1200/900" 
                    alt="Vidotor Interface" 
                    className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-[2s]"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-primary/10 group-hover:bg-transparent transition-colors duration-700" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <motion.div 
                      whileHover={{ scale: 1.1 }}
                      className="w-24 h-24 bg-white rounded-full flex items-center justify-center shadow-2xl cursor-pointer group/play"
                    >
                      <Play className="w-10 h-10 text-primary fill-current group-hover/play:scale-110 transition-transform" />
                    </motion.div>
                  </div>
                  {/* Floating UI Elements */}
                  <div className="absolute top-10 right-10 p-4 bg-white rounded-2xl shadow-xl border border-border animate-bounce-slow">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-status-approved rounded-full flex items-center justify-center">
                        <CheckCircle2 className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <p className="text-[10px] font-bold uppercase tracking-widest text-text-muted">Status</p>
                        <p className="text-xs font-bold">Approved by Client</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-40 px-8">
        <div className="max-w-[1400px] mx-auto">
          <div className="flex flex-col lg:flex-row justify-between items-end mb-24 gap-10">
            <div className="max-w-2xl">
              <h2 className="text-5xl md:text-7xl font-extrabold tracking-tighter mb-8 leading-tight">
                Designed for the <br />
                <span className="text-primary">modern workflow.</span>
              </h2>
              <p className="text-xl text-text-secondary font-medium leading-relaxed">
                We've stripped away the complexity of enterprise tools to give you a focused, beautiful experience that your clients will actually love using.
              </p>
            </div>
            <div className="pb-4">
              <Button variant="outline" className="rounded-full px-8 h-14 border-border-strong hover:bg-accent-peach hover:text-primary transition-all font-bold">
                Explore all features
              </Button>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-10">
            <FeatureCard 
              icon={<Youtube className="w-8 h-8" />}
              title="YouTube Integration"
              description="Host your review videos on YouTube as unlisted. No storage limits, no extra costs, just seamless playback."
              delay={0.1}
            />
            <FeatureCard 
              icon={<MessageSquare className="w-8 h-8" />}
              title="Timeline Feedback"
              description="Clients leave notes at specific timestamps. Click any note to jump exactly to that frame in the video."
              delay={0.2}
            />
            <FeatureCard 
              icon={<Share2 className="w-8 h-8" />}
              title="Instant Sharing"
              description="Generate a secure review link in one click. Your clients don't even need an account to leave feedback."
              delay={0.3}
            />
          </div>
        </div>
      </section>

      {/* Asymmetrical Content Section */}
      <section className="py-40 bg-section relative overflow-hidden bg-grid-subtle">
        <div className="max-w-[1400px] mx-auto px-8">
          <div className="grid lg:grid-cols-2 gap-32 items-center">
            <div className="relative order-2 lg:order-1">
              <div className="aspect-square rounded-[40px] overflow-hidden rotate-3 shadow-2xl">
                <img src="https://picsum.photos/seed/vidotor-creative/1000/1000" className="w-full h-full object-cover" alt="" referrerPolicy="no-referrer" />
              </div>
              <div className="absolute -bottom-10 -right-10 w-64 h-64 bg-accent-peach rounded-[40px] -rotate-6 -z-10" />
            </div>
            <div className="order-1 lg:order-2">
              <h2 className="text-5xl md:text-6xl font-extrabold tracking-tighter mb-10 leading-tight">
                Your creative <br />
                process, <span className="italic">elevated.</span>
              </h2>
              <div className="space-y-8">
                {[
                  { title: "Faster Approvals", desc: "Reduce revision cycles by 40% with clearer visual communication." },
                  { title: "Client Delight", desc: "Give your clients a premium experience that reflects your brand quality." },
                  { title: "Organized Revisions", desc: "Keep all feedback in one place, linked to specific moments in time." }
                ].map((item, i) => (
                  <div key={i} className="flex gap-6 group">
                    <div className="w-12 h-12 rounded-2xl bg-white border border-border flex items-center justify-center shrink-0 group-hover:bg-primary group-hover:text-white transition-all">
                      <span className="font-bold text-lg">0{i+1}</span>
                    </div>
                    <div>
                      <h4 className="text-xl font-bold mb-2">{item.title}</h4>
                      <p className="text-text-secondary font-medium leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-40 px-8">
        <div className="max-w-[1000px] mx-auto text-center mb-24">
          <h2 className="text-5xl md:text-7xl font-extrabold tracking-tighter mb-8">Simple, honest pricing.</h2>
          <p className="text-xl text-text-secondary font-medium">No hidden fees. No per-user pricing. Just one plan for everyone.</p>
        </div>

        <div className="max-w-[500px] mx-auto">
          <div className="p-12 rounded-[40px] bg-white border-2 border-primary shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 bg-primary text-white px-6 py-2 rounded-bl-2xl text-[10px] font-extrabold uppercase tracking-widest">Most Popular</div>
            <h3 className="text-3xl font-extrabold mb-2">Pro Creator</h3>
            <div className="flex items-baseline gap-2 mb-8">
              <span className="text-6xl font-extrabold tracking-tighter">$29</span>
              <span className="text-text-muted font-bold">/month</span>
            </div>
            <ul className="space-y-5 mb-12">
              {[
                "Unlimited Projects",
                "Unlimited Videos",
                "Custom Branding",
                "Priority Support",
                "YouTube Integration",
                "Password Protected Links"
              ].map(feature => (
                <li key={feature} className="flex items-center gap-3 font-medium">
                  <CheckCircle2 className="w-5 h-5 text-primary" />
                  {feature}
                </li>
              ))}
            </ul>
            <Button 
              onClick={handleLogin} 
              disabled={isLoading}
              className="w-full bg-primary hover:bg-primary-hover text-white h-16 rounded-full text-lg font-bold shadow-xl shadow-primary/20 disabled:opacity-50"
            >
              {isLoading ? 'Signing In...' : 'Get Started Now'}
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Footer */}
      <footer className="pt-40 pb-20 px-8 bg-foreground text-white rounded-t-[60px] bg-grid-light">
        <div className="max-w-[1400px] mx-auto">
          <div className="text-center mb-32">
            <h2 className="text-6xl md:text-9xl font-extrabold tracking-tighter mb-12 leading-[0.85]">
              Ready to <br />
              <span className="text-primary italic">transform</span> <br />
              your workflow?
            </h2>
            <Button 
              onClick={handleLogin}
              disabled={isLoading}
              size="lg" 
              className="bg-white text-foreground hover:bg-accent-peach hover:text-primary px-12 h-20 text-xl font-bold rounded-full transition-all hover:scale-105 disabled:opacity-50"
            >
              {isLoading ? 'Signing In...' : 'Join Vidotor Today'}
            </Button>
          </div>

          <div className="grid md:grid-cols-4 gap-16 border-t border-white/10 pt-20">
            <div className="col-span-2">
              <div className="flex items-center gap-3 mb-8">
                <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                  <LayoutDashboard className="w-6 h-6 text-white" />
                </div>
                <span className="text-2xl font-extrabold tracking-tighter">Vidotor</span>
              </div>
              <p className="text-white/60 max-w-xs font-medium leading-relaxed">
                The premium video feedback platform for creators who care about style and substance.
              </p>
            </div>
            <div>
              <h5 className="font-bold uppercase tracking-widest text-[11px] mb-8 text-white/40">Product</h5>
              <ul className="space-y-4 text-sm font-bold">
                <li><a href="#" className="hover:text-primary transition-colors">Features</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Pricing</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Changelog</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-bold uppercase tracking-widest text-[11px] mb-8 text-white/40">Connect</h5>
              <ul className="space-y-4 text-sm font-bold">
                <li><a href="#" className="hover:text-primary transition-colors">Twitter</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Instagram</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Support</a></li>
              </ul>
            </div>
          </div>
          <div className="mt-32 flex flex-col md:flex-row justify-between items-center gap-8 text-[11px] font-bold uppercase tracking-[0.2em] text-white/30">
            <p>© 2024 Vidotor. All rights reserved.</p>
            <div className="flex gap-12">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

